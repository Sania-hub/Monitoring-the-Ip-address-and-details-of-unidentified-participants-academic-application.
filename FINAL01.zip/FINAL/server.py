from atexit import register
import socket 
import threading
import mysql.connector


HEADER = 64
PORT = 50
SERVER = "127.0.0.1"
# socket.gethostbyname(socket.gethostname())
ADDR = (SERVER, PORT)
FORMAT = 'utf-8'
DISCONNECT_MESSAGE = "!DISCONNECT"

#here
mydb = mysql.connector.connect(
    host = "localhost",
    user = "root",
    passwd = "1234",
    database = "details"
    )
#end


h = ""
m = ""
n = ""
s = ""

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)

def handle_client(conn, addr):
    print(f"[NEW CONNECTION] {addr} connected.")

    connected = True
    while connected:
        msg_length = conn.recv(HEADER).decode(FORMAT)
        if msg_length:
            msg_length = int(msg_length)
            msg = conn.recv(msg_length).decode(FORMAT)
            # put condition here to check from database if hash exists or not. if it does, go to else and accept login details
            # if hash does not exist then accept registeration details.
            if msg_length == 40:
                h = msg  
                validate()
                if validate():
                    msg.split("!")

                elif msg_length == 29:
                    
                
                

            # if msg_length == 23:
            #     x = msg.split("!")
                          
                
            # if msg_length == 17:
            #     m = msg
                
            # if msg_length == 22:
            #     s = msg
                
            # if msg_length == 15:
            #     n = msg
                
            
                    if msg == DISCONNECT_MESSAGE:
                        connected = False

            print(f"[{addr}] {msg}")
            conn.send("Msg received".encode(FORMAT))

    conn.close()
        

def start():
    server.listen()
    print(f"[LISTENING] Server is listening on {SERVER}")
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()
        print(f"[ACTIVE CONNECTIONS] {threading.activeCount() }")

def validate():
    print("[STARTING] server is starting...")

start()