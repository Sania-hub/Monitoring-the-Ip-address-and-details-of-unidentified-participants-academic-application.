import re
email2=input("Enter email")
e= re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
if e.match(email2):
    print('valid email address!')
else:
    print("inValid")