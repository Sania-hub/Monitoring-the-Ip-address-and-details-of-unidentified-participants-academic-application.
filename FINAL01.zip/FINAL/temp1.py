


email2 = "qweqw"
password2 = "qweqwe"
name = "qwer"
roll_no = "123"
stream = "cse" 
specialisation = "btech"



email2+"!"+password2+"!"+name+"!"+roll_no+"!"+stream+"!"+specialisation