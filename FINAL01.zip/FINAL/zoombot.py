import pyautogui
import os
import time


def zoom():
    cmd=r"C:\Users\chsan\AppData\Roaming\Zoom\bin\Zoom.exe"
    os.system(cmd)
zoom()
time.sleep(1)
a="94496495660"
os.chdir("C:\Users\chsan\Desktop\FINAL\img")
print(os.getcwd())
s1 = pyautogui.locateOnScreen('dark.png', confidence=0.9)
print(s1)
pyautogui.leftClick(s1)
time.sleep(1)

s2 = pyautogui.locateOnScreen('dark2.png', confidence=0.9)
print(s2)
pyautogui.leftClick(s2)
pyautogui.typewrite(a,interval=0.01)
time.sleep(1)


s3 = pyautogui.locateOnScreen('dark3.png', confidence=0.9)
print(s3)
pyautogui.leftClick(s3)
