import socket
from encode import *
from rushil import *


HEADER = 64
PORT = 50
FORMAT = 'utf-8'
DISCONNECT_MESSAGE = "!DISCONNECT"
SERVER = "127.0.0.1"
ADDR = (SERVER, PORT)


client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(ADDR)

def send(msg):
    message = msg.encode(FORMAT)
    msg_length = len(message)
    send_length = str(msg_length).encode(FORMAT)
    send_length += b' ' * (HEADER - len(send_length))
    client.send(send_length)
    client.send(message)
    print(client.recv(2048).decode(FORMAT))


# hash = getHash()
# send(hash)
# mac = getMac()
# send(mac)
# serial = getMachine_addr()
# send(serial)
# name = getName()
# send(name)
email2 = "qweqw"
password2 = "qweqwe"
name = "qwer"
roll_no = "123"
stream = "cse" 
specialisation = "btech"

x = email2+"!"+password2+"!"+name+"!"+roll_no+"!"+stream+"!"+specialisation

send(a4)

send("This is registeration details")   # LENGTH = 29
send(x)




send(DISCONNECT_MESSAGE)