import os, sys
import re, uuid
import hashlib
import platform

def getName():
    name = platform.node()
    return name
a1=getName()

def getMachine_addr():
    os_type = sys.platform.lower()
    if "win" in os_type:
        command = "wmic bios get serialnumber"
    return os.popen(command).read().replace("\n","").replace(" ","").replace(" ","")
addr = getMachine_addr()
a2 = addr.replace('SerialNumber', '')

def getMac():  
    a = (':'.join(re.findall('..', '%012x' % uuid.getnode())))
    return a
a3=getMac()

def getHash():
    p = getMac() + getMachine_addr() + getName()
    uid = hashlib.sha1(p.encode())
    uuid = uid.hexdigest()    
    return uuid
a4=getHash()
