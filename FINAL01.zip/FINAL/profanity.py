from better_profanity import profanity

profanity.load_censor_words()

text = "hi paani lelo,hello fuck!"
censored_text = profanity.censor(text)
print(censored_text)


#For teachers to append
custom_badwords = ['hi', 'hello', 'lelo']
profanity.add_censor_words(custom_badwords)
a=profanity.contains_profanity(text)
print(profanity.censor(text))

